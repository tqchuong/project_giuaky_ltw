package fit.hcmuaf.edu.vn.foodmart.dao;

import fit.hcmuaf.edu.vn.foodmart.dao.db.DBConnect;
import fit.hcmuaf.edu.vn.foodmart.model.Discount;
import fit.hcmuaf.edu.vn.foodmart.model.Products;
import org.jdbi.v3.core.Handle;
import org.jdbi.v3.core.Jdbi;

import java.util.List;

public class DiscountDAO {

    private static Jdbi jdbi = DBConnect.getJdbi(); // Lấy Jdbi từ DBConnect

    // Lấy tất cả sản phẩm đang được giảm giá trong thời gian còn hiệu lực
    public List<Discount> getActiveDiscounts() {
        String sql = "SELECT d.Id AS discountId, d.ProductID AS productId, d.DiscountPercentage, " +
                "d.StartDate, d.EndDate, d.Status, " +
                "p.ProductName AS productName, p.Price AS productPrice, p.ImageURL AS productImage, p.StockQuantity AS productStock " +
                "FROM Discounts d " +
                "JOIN Products p ON d.ProductID = p.Id " +
                "WHERE d.StartDate <= CURRENT_TIMESTAMP AND d.EndDate >= CURRENT_TIMESTAMP " +  // Lọc các giảm giá còn hiệu lực
                "ORDER BY d.StartDate DESC"; // Lọc giảm giá theo thời gian bắt đầu

        try (Handle handle = jdbi.open()) {
            return handle.createQuery(sql)
                    .map((rs, ctx) -> {
                        Discount discount = new Discount();
                        discount.setId(rs.getInt("discountId"));
                        discount.setProductId(rs.getInt("productId"));
                        discount.setDiscountPercentage(rs.getDouble("DiscountPercentage"));
                        discount.setStartDate(rs.getTimestamp("StartDate"));
                        discount.setEndDate(rs.getTimestamp("EndDate"));
                        discount.setStatus(rs.getString("Status"));

                        // Thêm thông tin sản phẩm vào đối tượng Discount
                        Products product = new Products();
                        product.setProductID(rs.getInt("productId"));
                        product.setProductName(rs.getString("productName"));
                        product.setPrice(rs.getDouble("productPrice"));
                        product.setImageURL(rs.getString("productImage"));
                        product.setStockQuantity(rs.getInt("productStock"));

                        // Gán thông tin sản phẩm vào đối tượng Discount
                        discount.setProduct(product);

                        return discount;
                    })
                    .list();
        } catch (Exception e) {
            System.out.println("Lỗi khi truy vấn các giảm giá: " + e.getMessage());
            return null;
        }
    }

    // Test phương thức
    public static void main(String[] args) {
        DiscountDAO dao = new DiscountDAO();

        // Lấy danh sách các giảm giá còn hiệu lực
        List<Discount> activeDiscounts = dao.getActiveDiscounts();

        if (activeDiscounts != null && !activeDiscounts.isEmpty()) {
            System.out.println("Danh sách giảm giá còn hiệu lực:");
            for (Discount discount : activeDiscounts) {
                // Tính giá giảm
                double discountedPrice = discount.getProduct().getPrice() * (1 - discount.getDiscountPercentage() / 100);
                System.out.println("Sản phẩm: " + discount.getProduct().getProductName() +
                        ", Giá gốc: " + discount.getProduct().getPrice() +
                        ", Phần trăm giảm: " + discount.getDiscountPercentage() + "%" +
                        ", Giá sau giảm: " + discountedPrice +
                        ", Số lượng tồn: " + discount.getProduct().getStockQuantity() +
                        ", Thời gian áp dụng: Từ " + discount.getStartDate() + " đến " + discount.getEndDate() +
                        ", Trạng thái: " + discount.getStatus());
            }
        } else {
            System.out.println("Không có giảm giá nào còn hiệu lực hoặc có lỗi khi truy vấn.");
        }
    }
}
